<div class="container box-light p-2 rounded-3">
    <form class="row g-2" id="formPisoAdd"> <?php echo csrf_field(); ?>
        <h4 id="formTitleAdd" class="formTitle">Pisos o zonas</h4>
        <hr>
        <div class="alert-send" id="alerts_piso"></div>
        <input type="hidden" id="idFlat" name="idFlat">
        <div class="col-lg-6">
            <label for="name-flat" class="form-label">Piso o Zona*</label>
            <input type="text" class="form-control" id="name-flat" name="name-flat"
                placeholder="Nombre del piso o zona" required>
        </div>
        <div class="col-lg-6">
            <label for="status-flat" class="form-label">Estado*</label>
            <select name="status-flat" id="status-flat" class="form-select">
                <option value="">Selecciona una opción</option>
                <option value="active" selected>Activo</option>
                <option value="inactive">Inactivo</option>
            </select>
        </div>
        <div class="col-lg-12 col-md-12 col-sm-12 col-12 mt-3">
            <button id="addFormFlats" type="button" class="btn btn-primary btnFormAdd">Agregar</button>
            <button id="editFormFlats" type="button" style="display: none" class="btn btn-primary btnFormEdit">Editar</button>
            <button id="cancelFormFlats" type="button" style="display: none" class="btn btn-danger btnformCancel">Cancelar</button>
        </div>
        <div class="col-lg-6 col-md-6 col-sm-6 col-6 mt-3  d-flex justify-content-center" class="send_form_spinner">
            <div class="spinner-border preloadSend" style="display: none" id="preloadSend"></div>
        </div>
    </form>
</div>

<?php $__env->startPush('script_page'); ?>
    <script>
        addFlats();
    </script>
<?php $__env->stopPush(); ?>
<?php /**PATH C:\xampp\htdocs\Laravel\hotel\resources\views/components/forms/form-piso-add.blade.php ENDPATH**/ ?>