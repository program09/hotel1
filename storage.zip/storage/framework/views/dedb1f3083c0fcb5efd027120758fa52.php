<div class="container box-light p-2 rounded-3">
    <form action="" class="row g-2" id="formTypeAdd">
        <h4>Tipos de habitaciónes</h4>
        <hr>
        <div class="alert-send" id="alerts_type"></div>
        <div class="col-lg-6">
            <label for="name-type" class="form-label">Tipo*</label>
            <input type="text" class="form-control" id="name-type" name="name-type" placeholder="Tipo" required>
        </div>
        <div class="col-lg-6">
            <label for="status-type" class="form-label">Estado*</label>
            <select name="status-type" id="status-type" class="form-select">
                <option value="">Selecciona una opción</option>
                <option value="active" selected>active</option>
                <option value="inactive">inactive</option>
            </select>
        </div>
        <div class="col-lg-12 col-md-12 col-sm-12 col-12 mt-3">
            <button id="addFormTypeRoom" type="button" class="btn btn-primary btnFormAdd">Agregar</button>
            <button id="editFormTypeRoom" type="button" style="display: none"
                class="btn btn-primary btnFormEdit">Editar</button>
            <button id="cancelFormTypeRoom" type="button" style="display: none"
                class="btn btn-danger btnformCancel">Cancelar</button>
        </div>
        <div class="col-lg-6 col-md-6 col-sm-6 col-6 mt-3  d-flex justify-content-center" class="send_form_spinner">
            <div class="spinner-border preloadSend" style="display: none" id="preloadSendType"></div>
        </div>
    </form>
</div>

<?php $__env->startPush('script_page'); ?>
    <script>
        function addTypeRoom() {

            $('#addFormTypeRoom').click(function() {
                var formData = $('#formTypeAdd').serialize();
                $.ajax({
                    type: "post",
                    url: "/flat-add",
                    data: formData,
                    beforeSend: function() {
                        $('#preloadSendType').show();
                    },
                    success: function(response) {
                        console.log(response);
                        getFlatsAll();
                        $('#preloadSendType').hide();
                        alertB5('alerts_piso', 'success', response.message);
                        closeForm('formTypeAdd');
                    },
                    error: function(xhr, status, error) {
                        $('#preloadSendType').hide();
                        errorList(xhr);

                    }
                });

            });
        }

        addTypeRoom();
    </script>
<?php $__env->stopPush(); ?>
<?php /**PATH C:\xampp\htdocs\Laravel\hotel\resources\views/components/forms/form-tipo-room.blade.php ENDPATH**/ ?>