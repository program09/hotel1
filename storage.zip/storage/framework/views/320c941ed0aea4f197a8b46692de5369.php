<div class="table-responsive">
    <table class="table table-borderless align-middle" id="typeRoomTable">
        <thead>
            <tr>
                <th>Tipo</th>
                <th>Estado</th>
                <th> </th>
            </tr>
        </thead>
        <tbody>

        </tbody>
    </table>
</div>

<?php $__env->startPush('script_page'); ?>
    <script>
        getTypeRoomsAll();

        function getTypeRoomsAll() {
            $.ajax({
                type: "get",
                url: "/type-room-all",
                beforeSend: function() {

                },
                success: function(response) {
                    console.log(response);
                    $('#typeRoomTable tbody').empty();
                    $.each(response, function(index, typeroom) {
                        var badgeClass = typeroom.status === 'active' ? 'bg-success' : 'bg-danger';
                        var row = '<tr>' +
                            '<td>' + typeroom.type + '</td>' +
                            '<td><span class="badge ' + badgeClass + '">' + typeroom.status +
                            '</span></td>' +
                            '<td>' +
                            '<button class="btn btn-primary btn-sm btn-edit-type-room" data-id="' +
                            typeroom.id + '"><i class="fa-light fa-pen-to-square"></i></button>' +
                            '<button class="btn btn-danger btn-sm btn-eliminar-type-room" data-id="' +
                            typeroom.id + '"><i class="fa-light fa-trash-can"></i></button>' +
                            '</td>' +
                            '</tr>';
                        $('#typeRoomTable tbody').append(row);
                    });
                    $('.btn-eliminar-type-room').click(function(e) {
                        e.preventDefault();
                        msgAlertDeleteTypeRoom(this);
                    });

                }
            });
        }


    </script>
<?php $__env->stopPush(); ?>
<?php /**PATH C:\xampp\htdocs\Laravel\hotel\resources\views/components/tables/table-tipo-room.blade.php ENDPATH**/ ?>