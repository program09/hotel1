<header class="header box-light">
    <div class="h-left d-flex align-items-center gap-4">
        <button class="btn-icon-20" id="btn-aside"><i class="fa-light fa-bars-sort"></i></button>
        <img src="https://iconape.com/wp-content/files/us/77525/png/monday-1.png" alt="logo" class="logo">
    </div>
    <div class="h-right">
        <div class="btn-group gap-3 position-relative">
            <button type="button" class="btn-icon-20" id="toggleDark">
                <i class="fa-solid fa-moon-stars"></i>
                <i class="fa-sharp fa-solid fa-sun"></i>
            </button>
            <button type="button" class="btn-icon-20">
                <img id="btn-menu" src="<?php echo e(asset('storage/images/user/')); ?>/<?php echo e(Auth::user()->photo); ?>" class="user-photo-1">
            </button>
            <div class="menu box-light br-15" id="menu-h">
                <ul class="lista-v lista-hover-1 lista-icon">
                    <li class="item-v"><a href="perfil.html" class="link-v"><span><i class="fa-light fa-user"></i></span>Perfíl</a></li>
                    <li class="item-v"><a href="ajustes.html" class="link-v"><span><i class="fa-light fa-sliders"></i></span>Ajustes</a></li>
                    <li class="item-v">
                        <a href="#" onclick="event.preventDefault(); document.getElementById('logout-form').submit();" class="link-v"><span><i class="fa-light fa-right-from-bracket"></i></span>Salir</a>
                        <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;"><?php echo csrf_field(); ?></form>
                    </li>
                </ul>
            </div>
        </div>
    </div>
</header>
<?php /**PATH C:\xampp\htdocs\Laravel\hotel\resources\views/components/header/header-main.blade.php ENDPATH**/ ?>