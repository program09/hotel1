<aside class="aside-1 box-light">
    <div class="aside-head">
        <p class="txt-1 txt-point"><span><?php echo e(Auth::user()->name .' '. Auth::user()->lastname); ?></span></p>
        <p><?php echo e(Auth::user()->email); ?></p>
        <p class="txt-3"><span><?php echo e(Auth::user()->status); ?></span></p>
    </div>
    <div class="aside-body">
        <ul class="lista-v lista-hover-2 lista-icon">
            <li class="item-v"><a href="<?php echo e(route('home')); ?>" class="link-v"><span><i class="fa-light fa-home-user"></i></span>Inicio</a></li>
            <li class="item-v"><a href="" class="link-v"><span><i class="fa-light fa-user"></i></span>Perfíl</a> </li>
            <li class="item-v"><a href="ajustes.html" class="link-v"><span><i class="fa-light fa-sliders"></i></span>Ajustes</a></li>
        </ul>
        <hr>
        <div id="accordion">
            <div class="accordion">
                <div class="accordion-header">
                    <a class="accordion-btn txt-3" data-bs-toggle="collapse" href="#collapseOne">Panel del
                        hotel</a>
                </div>
                <div id="collapseOne" class="collapse show" data-bs-parent="#accordion">
                    <div class="accordion-body">
                        <ul class="lista-v lista-hover-2 lista-icon">
                            <li class="item-v"><a href="<?php echo e(route('habitaciones')); ?>" class="link-v"><span><i class="fa-light fa-bed"></i></span>Habitaciones</a></li>
                            <li class="item-v"><a href="<?php echo e(route('reservas')); ?>" class="link-v"><span><i class="fa-light fa-bookmark"></i></span>Reservas</a></li>
                            <li class="item-v"><a href="<?php echo e(route('huespedes')); ?>" class="link-v"><span><i class="fa-light fa-users"></i></span>Huespedes</a></li>
                            <li class="item-v"><a href="<?php echo e(route('historial')); ?>" class="link-v"><span><i class="fa-light fa-list-check"></i></span>Historial de visitas</a></li>
                            <li class="item-v"><a href="<?php echo e(route('trabajadores')); ?>" class="link-v"><span><i class="fa-light fa-user-tie"></i></span>Trabajadores</a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
</aside>
<?php /**PATH C:\xampp\htdocs\Laravel\hotel\resources\views/components/aside/aside-main.blade.php ENDPATH**/ ?>