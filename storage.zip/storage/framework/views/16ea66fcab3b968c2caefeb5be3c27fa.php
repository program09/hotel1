<form class="row g-3 needs-validation" novalidate>
    <h4>Reservar habitación</h4>
    <hr>
    <h6>Datos del huesped</h6>
    <div class="col-md-6">
        <label for="validationCustom01" class="form-label">DNI / RUC</label>
        <select class="form-select" aria-label="multiple select example">
            <option value="dni">DNI</option>
            <option value="ruc">RUC</option>
        </select>
        <div class="valid-feedback">
            Looks good!
        </div>
    </div>
    <div class="col-md-6">
        <label for="validationCustom01" class="form-label">Número</label>
        <input type="text" class="form-control" id="validationCustom01" placeholder="DNI o RUC" required>
        <div class="valid-feedback">
            Looks good!
        </div>
    </div>
    <div class="col-md-7">
        <label for="validationCustom02" class="form-label">Nombre</label>
        <input type="text" class="form-control" id="validationCustom02" placeholder="Nombres completos" required>
        <div class="valid-feedback">
            Looks good!
        </div>
    </div>
    <div class="col-md-5">
        <label for="validationCustom02" class="form-label">Celular</label>
        <input type="text" class="form-control" id="validationCustom02" placeholder="Celular" required>
        <div class="valid-feedback">
            Looks good!
        </div>
    </div>
    <hr>
    <h6>Fecha de entrada y salida</h6>
    <div class="col-md-6">
        <label for="validationCustom03" class="form-label">Entrada</label>
        <input type="date" class="form-control" id="validationCustom03" required>
        <div class="invalid-feedback">
            Please provide a valid city.
        </div>
    </div>
    <div class="col-md-6">
        <label for="validationCustom03" class="form-label">Hora</label>
        <input type="time" class="form-control" id="validationCustom03" required>
        <div class="invalid-feedback">
            Please provide a valid city.
        </div>
    </div>
    <div class="col-md-6">
        <label for="validationCustom03" class="form-label">Salida</label>
        <input type="date" class="form-control" id="validationCustom03" required>
        <div class="invalid-feedback">
            Please provide a valid city.
        </div>
    </div>
    <div class="col-md-6">
        <label for="validationCustom03" class="form-label">Hora</label>
        <input type="time" class="form-control" id="validationCustom03" required>
        <div class="invalid-feedback">
            Please provide a valid city.
        </div>
    </div>
    <div class="col-12">
        <div class="form-check">
            <input class="form-check-input" type="checkbox" value="" id="invalidCheck" required>
            <label class="form-check-label" for="invalidCheck">
                Solo pasar la noche
            </label>
        </div>
    </div>
    <hr>
    <h6>Sellección de habitaciones</h6>
    <div class="col-md-4">
        <label for="habitacionSelect" class="form-label">Tipo: </label>
        <select id="habitacionSelect" class="form-select" aria-label="select habitacion">
            <option value="Simple">Simple</option>
            <option value="Doble">Doble</option>
        </select>
        <div class="valid-feedback">
            Looks good!
        </div>
    </div>

    <div class="col-md-5">
        <label for="numeroSelect" class="form-label">Habitación</label>
        <select id="numeroSelect" class="form-select" aria-label="select numero">
            <option value="">Seleccione</option>
            <option value="123">123</option>
            <option value="456">456</option>
        </select>
    </div>
    <div class="col-md-3">
        <label for="" class="form-label">Agregar</label>
        <button type="button" id="agregarBtn" class="btn btn-success form-control">+</button>
    </div>

    <div id="alertContainer" class="col-md-12"></div>

    <div class="table-responsive">
        <table id="tablaHabitaciones" class="table table-borderless align-middle">
            <thead>
                <tr>
                    <th>Habitación</th>
                    <th>S/.</th>
                    <th> </th>
                </tr>
            </thead>
            <tbody>
            </tbody>
        </table>
    </div>
    <hr>
    <p>Total: s/ 200</p>
    <div class="col-12 d-flex align-items-center justify-content-between">
        <button class="btn btn-primary" type="submit">Reservar</button>
        <button type="button" class="btn btn-danger" data-bs-dismiss="modal">Cancelar</button>
    </div>
</form>
<?php /**PATH C:\xampp\htdocs\Laravel\hotel\resources\views/components/forms/form-reservar.blade.php ENDPATH**/ ?>