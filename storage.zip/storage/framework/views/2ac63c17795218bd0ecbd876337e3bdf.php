<div class="table-responsive">
    <table class="table table-borderless align-middle" id="flatTable">
        <thead>
            <tr>
                <th>Piso / Zona</th>
                <th>Estado</th>
                <th> </th>
            </tr>
        </thead>
        <tbody>
        </tbody>
    </table>
</div>


<?php $__env->startPush('script_page'); ?>
    <script>
        getFlatsAll();
        editFlats();
        editValLFlat()
        cancelFormEdit('formPisoAdd');
    </script>
<?php $__env->stopPush(); ?>
<?php /**PATH C:\xampp\htdocs\Laravel\hotel\resources\views/components/tables/table-piso.blade.php ENDPATH**/ ?>