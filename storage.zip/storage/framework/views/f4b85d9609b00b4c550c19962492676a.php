<?php $__env->startSection('title', 'Historial'); ?>

<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <?php echo $__env->make('components.header.breadcrumd-main', ['title' => 'Historial'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="section-1">
        <div class="box-light br-15 p-3 ">
            <div class="d-flex align-items-center gap-3" role="group" aria-label="Basic example">
                <button type="button" class="btn btn-warning">Reporte</button>
            </div>
        </div>
    </div>

    <div class="section-1">
        <div class="box-light p-3 br-15">
            <div class="table-responsive">
                <table class="table table-borderless align-middle">
                    <thead>
                        <tr>
                            <th>Cliente</th>
                            <th>DNI / RUC</th>
                            <th>Entrada</th>
                            <th>Salida</th>
                            <th>Estado</th>
                            <th> </th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td>Juan</td>
                            <td>98765432</td>
                            <td>10/08/2024 - 20:45</td>
                            <td><span class="badge bg-success">Hospedado</span>
                            </td>
                            <td>
                                <button class="btn btn-primary btn-sm"><i
                                        class="fa-light fa-pen-to-square"></i></button>
                                <button class="btn btn-danger btn-sm"><i class="fa-light fa-trash-can"></i></button>
                            </td>
                        </tr>
                        <tr>
                            <td>Juan</td>
                            <td>98765432</td>
                            <td>10/08/2024 - 20:45</td>
                            <td><span class="badge bg-warning">En espera</span>
                            </td>
                            <td>
                                <button class="btn btn-primary btn-sm"><i
                                        class="fa-light fa-pen-to-square"></i></button>
                                <button class="btn btn-danger btn-sm"><i class="fa-light fa-trash-can"></i></button>
                            </td>
                        </tr>
                        <tr>
                            <td>Juan</td>
                            <td>98765432</td>
                            <td>10/08/2024 - 20:45</td>
                            <td><span class="badge bg-danger">Finalizado</span>
                            </td>
                            <td>
                                <button class="btn btn-primary btn-sm"><i
                                        class="fa-light fa-pen-to-square"></i></button>
                                <button class="btn btn-danger btn-sm"><i class="fa-light fa-trash-can"></i></button>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <?php if (isset($component)) { $__componentOriginal6416b32d4167d7d538062ec8c39271c8 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal6416b32d4167d7d538062ec8c39271c8 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.modaprueba','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('modaprueba'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
        aquí va el formulario
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal6416b32d4167d7d538062ec8c39271c8)): ?>
<?php $attributes = $__attributesOriginal6416b32d4167d7d538062ec8c39271c8; ?>
<?php unset($__attributesOriginal6416b32d4167d7d538062ec8c39271c8); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal6416b32d4167d7d538062ec8c39271c8)): ?>
<?php $component = $__componentOriginal6416b32d4167d7d538062ec8c39271c8; ?>
<?php unset($__componentOriginal6416b32d4167d7d538062ec8c39271c8); ?>
<?php endif; ?>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\Laravel\hotel\resources\views/pages/historial.blade.php ENDPATH**/ ?>