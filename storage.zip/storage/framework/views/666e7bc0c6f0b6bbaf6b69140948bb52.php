<div class="container p-2 rounded-3">
    <form action="" class="row g-2" id="formPiso">
        <h4>Habitaciones</h4><hr>
        <div class="col-lg-6">
            <label for="name-room" class="form-label">Nombre o número*</label>
            <input type="text" class="form-control" id="name-room" name="name-room" placeholder="Nombre o número" required>
        </div>

        <div class="col-lg-6">
            <label for="count-room" class="form-label">Cantidad de personas*</label>
            <input type="number" class="form-control" id="count-room" name="count-room" placeholder="Cantidad de personas" required>
        </div>

        <div class="col-lg-6">
            <label for="type-room" class="form-label">Tipo*</label>
            <select name="type-room" id="type-room" class="form-select">
                <option value=""  selected>Selecciona una opción</option>
                <option value="active">active</option>
                <option value="inactive">inactive</option>
            </select>
        </div>
        <div class="col-lg-6">
            <label for="piso-room" class="form-label">Piso / Zona*</label>
            <select name="piso-room" id="piso-room" class="form-select">
                <option value=""  selected>Selecciona una opción</option>
                <option value="active">active</option>
                <option value="inactive">inactive</option>
            </select>
        </div>

        <div class="col-lg-6">
            <label for="price-room" class="form-label">Precio s/.*</label>
            <input type="text" class="form-control" id="price-room" name="price-room" placeholder="Precio s/." required>
        </div>

        <div class="col-lg-6">
            <label for="status-room" class="form-label">Estado*</label>
            <select name="status-room" id="status-room" class="form-select">
                <option value="">Selecciona una opción</option>
                <option value="active" selected>active</option>
                <option value="inactive">inactive</option>
            </select>
        </div>
        <div class="col-lg-12 mt-4">
            <button class="w-100 btn btn-primary float-right">Agregar</button>
        </div>
    </form>
</div>
<?php /**PATH C:\xampp\htdocs\Laravel\hotel\resources\views/components/forms/form-room-add.blade.php ENDPATH**/ ?>