<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $__env->yieldContent('title', 'Hoteles'); ?></title>
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <!-- ------------------------------- ICONOS -------------------------------- -->
    <link rel="stylesheet" href="https://program09.github.io/YORDIALCANTARA/public/css/Icons/css/all.min.css">
    <!-- --------------------------- BOOTSTRAP 5  CSS -------------------------- -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- ------------------------------- JQUERY -------------------------------- -->
    <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
    <script src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.min.js"></script>
    <!-- Archivo de idioma en español -->
    <link rel="stylesheet" href="https://cdn.datatables.net/1.11.5/css/jquery.dataTables.min.css">
    <!-- ------------------------------ MAIN CSS ------------------------------- -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/main.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/main-dark.css')); ?>">
</head>

<body>

    <!-- ------------------------------- HEADER -------------------------------- -->
    <?php echo $__env->make('components.header.header-main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- ------------------------------- HEADER -------------------------------- -->

    <div class="content-all">
        <?php echo $__env->make('components.aside.aside-main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <main class="main-1">
            <?php echo e($slot); ?>

        </main>
    </div>

    <!-- --------------------------- BOOTSTRAP 5 JS ---------------------------- -->
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@10"></script>


    <!-- ------------------------------- MAIN JS ------------------------------- -->
    <script src="<?php echo e(asset('assets/js/main.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/ajax.js')); ?>"></script>

    <?php echo $__env->yieldPushContent('script_page'); ?>

</body>

</html>
<?php /**PATH C:\xampp\htdocs\Laravel\hotel\resources\views/layouts/app.blade.php ENDPATH**/ ?>