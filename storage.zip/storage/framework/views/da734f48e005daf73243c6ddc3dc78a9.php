<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet">

    <link rel="stylesheet" href="<?php echo e(asset('assets/css/404.css')); ?>">
</head>
<body>

    <div class="content-error">
        <img src="<?php echo e(asset('assets/img/404.svg')); ?>" alt="">
        <h4 class="text-light m-3 d-block">Página no encontrada</h4>
        <a href="<?php echo e(route('home')); ?>"><button class="btn btn-warning">Ir al inicio</button></a>
    </div>

</body>
</html>
<?php /**PATH C:\xampp\htdocs\Laravel\hotel\resources\views/errors/404.blade.php ENDPATH**/ ?>