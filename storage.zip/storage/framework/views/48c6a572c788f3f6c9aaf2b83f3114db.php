<?php $__env->startSection('title', 'Habitaciones'); ?>
<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>

    <?php echo $__env->make('components.header.breadcrumd-main', ['title' => 'Habitaciones'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="section-1">
        <div class="box-light br-15 p-3">
            <div class="d-flex align-items-center gap-3" role="group" aria-label="Basic example">
                <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#modal1">Agregar</button>
                <button type="button" class="btn btn-success" data-bs-toggle="modal" data-bs-target="#modal2">Pisos</button>
                <button type="button" class="btn btn-warning" data-bs-toggle="modal" data-bs-target="#modal3">Tipos</button>
            </div>
        </div>
    </div>

    <?php if (isset($component)) { $__componentOriginal9f64f32e90b9102968f2bc548315018c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9f64f32e90b9102968f2bc548315018c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.modal','data' => ['modalId' => 'modal1','modalxl' => 'modal-md','formId' => 'formRoom']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['modalId' => 'modal1','modalxl' => 'modal-md','formId' => 'formRoom']); ?>
        <?php echo $__env->make('components.forms.form-room-add', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9f64f32e90b9102968f2bc548315018c)): ?>
<?php $attributes = $__attributesOriginal9f64f32e90b9102968f2bc548315018c; ?>
<?php unset($__attributesOriginal9f64f32e90b9102968f2bc548315018c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9f64f32e90b9102968f2bc548315018c)): ?>
<?php $component = $__componentOriginal9f64f32e90b9102968f2bc548315018c; ?>
<?php unset($__componentOriginal9f64f32e90b9102968f2bc548315018c); ?>
<?php endif; ?>
    <?php if (isset($component)) { $__componentOriginal9f64f32e90b9102968f2bc548315018c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9f64f32e90b9102968f2bc548315018c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.modal','data' => ['modalId' => 'modal2','modalxl' => 'modal-md','formId' => 'formPiso']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['modalId' => 'modal2','modalxl' => 'modal-md','formId' => 'formPiso']); ?>
        <?php echo $__env->make('components.forms.form-piso-add', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> <hr>
        <?php echo $__env->make('components.tables.table-piso', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9f64f32e90b9102968f2bc548315018c)): ?>
<?php $attributes = $__attributesOriginal9f64f32e90b9102968f2bc548315018c; ?>
<?php unset($__attributesOriginal9f64f32e90b9102968f2bc548315018c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9f64f32e90b9102968f2bc548315018c)): ?>
<?php $component = $__componentOriginal9f64f32e90b9102968f2bc548315018c; ?>
<?php unset($__componentOriginal9f64f32e90b9102968f2bc548315018c); ?>
<?php endif; ?>
    <?php if (isset($component)) { $__componentOriginal9f64f32e90b9102968f2bc548315018c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9f64f32e90b9102968f2bc548315018c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.modal','data' => ['modalId' => 'modal3','modalxl' => 'modal-md','formId' => 'formTipo']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['modalId' => 'modal3','modalxl' => 'modal-md','formId' => 'formTipo']); ?>
        <?php echo $__env->make('components.forms.form-tipo-room', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> <hr>
        <?php echo $__env->make('components.tables.table-tipo-room', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9f64f32e90b9102968f2bc548315018c)): ?>
<?php $attributes = $__attributesOriginal9f64f32e90b9102968f2bc548315018c; ?>
<?php unset($__attributesOriginal9f64f32e90b9102968f2bc548315018c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9f64f32e90b9102968f2bc548315018c)): ?>
<?php $component = $__componentOriginal9f64f32e90b9102968f2bc548315018c; ?>
<?php unset($__componentOriginal9f64f32e90b9102968f2bc548315018c); ?>
<?php endif; ?>

    <div class="section-1">
        <div class="title-section box-light br-15 p-3 mb-4">
            <!-- Nav pills -->
            <ul class="nav nav-pills">
                <li class="nav-item">
                    <a class="nav-link active" data-bs-toggle="pill" href="#home">Piso 1</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" data-bs-toggle="pill" href="#menu1">Piso 2</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" data-bs-toggle="pill" href="#menu2">Piso 3</a>
                </li>
            </ul>
        </div>

        <!-- Tab panes -->
        <div class="tab-content">
            <div class="tab-pane active" id="home">
                <div class="grid-1">
                    <div class="grid-1-item box-light br-15 box-min d-block">
                        <div class="photo-room  position-relative">
                            <div class="status-room position-absolute m-1">
                                <span class="badge bg-danger badge-1">Ocupado</span><br>
                                <span class="badge bg-primary badge-1">Doble</span><br>
                                <span class="badge bg-secondary badge-1">s/ 40 x noche</span>
                            </div>

                            <img src="https://villaleonenairobi.com/static/images/roombg.jpg" alt="">
                        </div>
                        <div class="info-room mt-2">
                            <p>Habitación: <span class="">102</span></p>
                            <button class="w-100 btn btn-success mt-2">Mostrar</button>
                        </div>
                    </div>
                    <div class="grid-1-item box-light br-15 box-min d-block">
                        <div class="photo-room  position-relative">
                            <div class="status-room position-absolute m-1">
                                <span class="badge bg-warning badge-1">Libre</span><br>
                                <span class="badge bg-success badge-1">Simple</span><br>
                                <span class="badge bg-secondary badge-1">s/ 20 x noche</span>
                            </div>

                            <img src="https://villaleonenairobi.com/static/images/roombg.jpg" alt="">
                        </div>
                        <div class="info-room mt-2">
                            <p>Habitación: <span class="">102</span></p>
                            <button class="w-100 btn btn-success mt-2">Mostrar</button>
                        </div>
                    </div>
                </div>
            </div>
            <div class="tab-pane fade" id="menu1">
                <div class="grid-1">
                    <div class="grid-1-item box-light br-15 box-min d-block">
                        <div class="photo-room  position-relative">
                            <div class="status-room position-absolute m-1">
                                <span class="badge bg-danger badge-1">Ocupado</span><br>
                                <span class="badge bg-primary badge-1">Doble</span><br>
                                <span class="badge bg-secondary badge-1">s/ 40 x noche</span>
                            </div>

                            <img src="https://villaleonenairobi.com/static/images/roombg.jpg" alt="">
                        </div>
                        <div class="info-room mt-2">
                            <p>Habitación: <span class="">102</span></p>
                            <button class="w-100 btn btn-success mt-2">Mostrar</button>
                        </div>
                    </div>
                    <div class="grid-1-item box-light br-15 box-min d-block">
                        <div class="photo-room  position-relative">
                            <div class="status-room position-absolute m-1">
                                <span class="badge bg-warning badge-1">Libre</span><br>
                                <span class="badge bg-success badge-1">Simple</span><br>
                                <span class="badge bg-secondary badge-1">s/ 20 x noche</span>
                            </div>

                            <img src="https://villaleonenairobi.com/static/images/roombg.jpg" alt="">
                        </div>
                        <div class="info-room mt-2">
                            <p>Habitación: <span class="">102</span></p>
                            <button class="w-100 btn btn-success mt-2">Mostrar</button>
                        </div>
                    </div>
                </div>
            </div>
            <div class="tab-pane fade" id="menu2">
                <div class="grid-1">
                    <div class="grid-1-item box-light br-15 box-min d-block">
                        <div class="photo-room  position-relative">
                            <div class="status-room position-absolute m-1">
                                <span class="badge bg-danger badge-1">Ocupado</span><br>
                                <span class="badge bg-primary badge-1">Doble</span><br>
                                <span class="badge bg-secondary badge-1">s/ 40 x noche</span>
                            </div>

                            <img src="https://villaleonenairobi.com/static/images/roombg.jpg" alt="">
                        </div>
                        <div class="info-room mt-2">
                            <p>Habitación: <span class="">102</span></p>
                            <button class="w-100 btn btn-success mt-2">Mostrar</button>
                        </div>
                    </div>
                    <div class="grid-1-item box-light br-15 box-min d-block">
                        <div class="photo-room  position-relative">
                            <div class="status-room position-absolute m-1">
                                <span class="badge bg-warning badge-1">Libre</span><br>
                                <span class="badge bg-success badge-1">Simple</span><br>
                                <span class="badge bg-secondary badge-1">s/ 20 x noche</span>
                            </div>

                            <img src="https://villaleonenairobi.com/static/images/roombg.jpg" alt="">
                        </div>
                        <div class="info-room mt-2">
                            <p>Habitación: <span class="">102</span></p>
                            <button class="w-100 btn btn-success mt-2">Mostrar</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>



    </div>



    <?php $__env->startPush('script_page'); ?>

    <?php $__env->stopPush(); ?>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\Laravel\hotel\resources\views/pages/habitaciones.blade.php ENDPATH**/ ?>