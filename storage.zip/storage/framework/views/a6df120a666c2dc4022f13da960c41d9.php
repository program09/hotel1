<?php $__env->startSection('title', 'Reservas'); ?>

<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <?php echo $__env->make('components.header.breadcrumd-main', ['title' => 'Reservas'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="section-1">
        <div class="box-light br-15 p-3 ">
            <div class="d-flex align-items-center gap-3" role="group" aria-label="Basic example">
                <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#modal1">Agregar</button>
                <button type="button" class="btn btn-warning">Reporte</button>
            </div>
        </div>
    </div>

    <div class="section-1">
        <div class="box-light p-3 br-15">
            <div class="responsive-x">
                <div id='calendar'></div>
            </div>
        </div>
    </div>

    <?php if (isset($component)) { $__componentOriginal9f64f32e90b9102968f2bc548315018c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9f64f32e90b9102968f2bc548315018c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.modal','data' => ['modalId' => 'modal1']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['modalId' => 'modal1']); ?>
        <?php echo $__env->make('components.forms.form-reservar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9f64f32e90b9102968f2bc548315018c)): ?>
<?php $attributes = $__attributesOriginal9f64f32e90b9102968f2bc548315018c; ?>
<?php unset($__attributesOriginal9f64f32e90b9102968f2bc548315018c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9f64f32e90b9102968f2bc548315018c)): ?>
<?php $component = $__componentOriginal9f64f32e90b9102968f2bc548315018c; ?>
<?php unset($__componentOriginal9f64f32e90b9102968f2bc548315018c); ?>
<?php endif; ?>


    <?php $__env->startPush('script_page'); ?>
        <script src='https://cdn.jsdelivr.net/npm/fullcalendar@6.1.11/index.global.min.js'></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/fullcalendar/5.10.1/locales/es.min.js"></script>
        <script>
            document.addEventListener('DOMContentLoaded', function() {
                var calendarEl = document.getElementById('calendar');
                var calendar = new FullCalendar.Calendar(calendarEl, {
                    initialView: 'dayGridMonth',
                    locale: 'es',
                    editable: true,
                    droppable: true,
                    eventReceive: function(info) {
                        alert('Evento agregado: ' + info.event.title);
                    },
                    headerToolbar: {
                        left: 'prev,next today',
                        center: 'title',
                        right: 'dayGridMonth,timeGridWeek,timeGridDay',
                        end: 'listMonth'
                    },
                    select: function(info) {
                        alert('Fecha seleccionada: ' + info.start.toLocaleDateString('es', {
                            weekday: 'long',
                            year: 'numeric',
                            month: 'long',
                            day: 'numeric'
                        }));
                    }
                });
                calendar.render();
            });
            document.getElementById('agregarBtn').addEventListener('click', function() {
                // Obtener los valores seleccionados
                var habitacion = document.getElementById('habitacionSelect').value;
                var numeroSelect = document.getElementById('numeroSelect');
                var numero = numeroSelect.value;

                // Validar que se hayan seleccionado ambos valores
                if (habitacion && numero) {
                    // Verificar si el número ya existe en la tabla
                    var numerosEnTabla = Array.from(document.querySelectorAll('#tablaHabitaciones tbody tr')).map(row =>
                        row.cells[0].textContent.match(/\d+/g)[0]);
                    if (numerosEnTabla.includes(numero)) {
                        // Mostrar una alerta de Bootstrap si el número ya existe
                        var alerta = `<div id="alerta" class="alert alert-warning alert-dismissible fade show" role="alert">
                                La habitación número ${numero} está en la lista.
                                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                            </div>`;

                        document.getElementById('alertContainer').innerHTML = alerta;
                        numeroSelect.value = "";
                        // Eliminar la alerta después de 5 segundos
                        setTimeout(function() {
                            var alertaElement = document.getElementById('alerta');
                            if (alertaElement) {
                                alertaElement.remove();
                            }
                        }, 5000);
                    } else {
                        // Crear una nueva fila para la tabla
                        var newRow = document.createElement('tr');
                        newRow.innerHTML = `
                    <td>#${numero} <span class="badge bg-primary">${habitacion}</span></td>
                    <td>s/ 120</td>
                    <td>
                        <button class="btn btn-danger btn-sm"><i class="fa-regular fa-trash-can"></i></button>
                    </td>
                `;

                        // Agregar la nueva fila a la tabla
                        document.getElementById('tablaHabitaciones').getElementsByTagName('tbody')[0].appendChild(
                            newRow);

                        // Limpiar el valor del select de número para eliminar la opción seleccionada
                        numeroSelect.value = "";
                    }
                } else {
                    alert('Por favor seleccione una habitación y un número.');
                }
            });
        </script>
    <?php $__env->stopPush(); ?>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\Laravel\hotel\resources\views/pages/reservas.blade.php ENDPATH**/ ?>