<div class="modal fade" id="<?php echo e($modalId); ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true" data-bs-backdrop="static">
    <div class="modal-dialog modal-dialog-centered <?php echo e($modalxl); ?>">
        <div class="modal-content">
            <div class="modal-body position-relative">
                <button type="button" class="btn-icon-20 bg-danger rounded-3 btn-close-modal" onclick="closeFormModal('<?php echo e($formId); ?>');" data-bs-dismiss="modal"><i class="fa-regular fa-circle-xmark"></i></button>
                <?php echo e($slot); ?>

            </div>
        </div>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\Laravel\hotel\resources\views/components/modal.blade.php ENDPATH**/ ?>