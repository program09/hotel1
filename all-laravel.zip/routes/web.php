<?php

use App\Http\Controllers\FlatController;
use App\Http\Controllers\TyperoomController;
use App\Http\Controllers\UserController;
use Illuminate\Support\Facades\Route;

//ERRORES
Route::get('/403', function () {return view('errors.403');});

//LOGIN HOME
Route::get('/login', function () {return view('auth.login');});
Route::get('/', function () {return view('auth.login');});
Route::get('/dashboard', function () {return view('home');})->middleware(['auth', 'verified'])->name('dashboard');

/** RUTAS DE VISTAS AUTH */
Route::middleware('auth', 'userType:admin')->group(function () {
    Route::get('/home', function () {return view('pages.home');})->name('home');
    Route::get('/habitaciones', function () {return view('pages.habitaciones');})->name('habitaciones');
    Route::get('/reservas', function () {return view('pages.reservas');})->name('reservas');
    Route::get('/huespedes', function () {return view('pages.huespedes');})->name('huespedes');
    Route::get('/historial', function () {return view('pages.historial');})->name('historial');
    Route::get('/trabajadores', function () {return view('pages.workerd');})->name('trabajadores');
});


//CONTROLADORES
Route::get('/user-all', [UserController::class, 'listarUser'])->name('user.all');
Route::post('/user-add', [UserController::class, 'createUser'])->name('user.add');
Route::post('/user-delete', [UserController::class, 'deleteUser'])->name('user.delete');
Route::get('/user-show/{id}', [UserController::class, 'showUser'])->name('user.show');
Route::post('/user-reset', [UserController::class, 'reserUser'])->name('user.reset');
Route::post('/user-photo', [UserController::class, 'photoUser'])->name('user.photo');
Route::post('/user-update', [UserController::class, 'updateUser'])->name('user.update');


//PISOS O ZONAS
Route::get('/flat-all', [FlatController::class, 'listarflat'])->name('flat.all');
Route::post('/flat-add', [FlatController::class, 'createflat'])->name('flat.add');
Route::post('/flat-delete', [FlatController::class, 'deleteflat'])->name('flat.delete');
Route::put('/flat-edit/{id}', [FlatController::class, 'editFlat'])->name('flat.edit');

//TIPO DE HABITACIONES
Route::get('/type-room-all', [TyperoomController::class, 'showAll'])->name('type.room.all');
Route::post('/type-room-delete', [TyperoomController::class, 'deleteTypeRoom'])->name('type.room.delete');













require __DIR__ . '/auth.php';
