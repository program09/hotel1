<!doctype html>
<html lang="es">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-+0n0xVW2eSR5OomGNYDnhzAbDsOXxcvSN1TPprVMTNDbiYZCxYbOOl7+AMvyTG2x" crossorigin="anonymous">
    <title>Login</title>
    <link rel="stylesheet" href="https://program09.github.io/YORDIALCANTARA/public/css/Icons/css/all.min.css">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <link rel="stylesheet" href="{{ asset('assets/css/login.css') }}">
</head>

<body>

    <div class="content">
        <div class="wrapper">
            <div class="row w-100 m-auto">
                <div class="col-md-6 box col-img">
                    <h3>Es hora de restablecer tu contraseña</h3>
                    <p>Si no quieres restablecer tu contraseña no hagas nada, el enlace solo será valido por 60 minutos.</p>
                </div>
                <div class="col-md-6 box col-form">
                    <form method="POST" action="{{ route('password.store') }}"> @csrf
                        <h3 class="title-3">Nueva contraseña</h3>
                        <input type="hidden" name="token" value="{{ $request->route('token') }}">
                        <div class="group-input">
                            <label for="email">Correo electrónico:</label>
                            <input type="text" id="email" name="email" class="" placeholder="ejemplo@gmail.com" required  autocomplete="username" value="{{ request('email') }}">
                        </div>
                        <div class="group-input position-relative">
                            <label for="password">Contraseña nueva:</label>
                            <input type="password" id="password" name="password" placeholder="••••••••••" required autocomplete="new-password" autofocus>
                            <span id="togglePassword" class="position-absolute"><i class="fa-light fa-eye"></i></span>
                        </div>
                        <div class="group-input position-relative">
                            <label for="password_confirmation">Confirma tu contraseña:</label>
                            <input type="password" id="password_confirmation" name="password_confirmation" placeholder="••••••••••" required autocomplete="new-password" >
                        </div>
                        <button class="submit w-100 border-0 ">Restablecer mi contraseña</button>
                        <a href="" class="link-only mt-3 d-block">Ir a iniciar sesión</a>
                    </form>
                </div>
            </div>
        </div>

        <script>
            $('#togglePassword').click(function (e) {
                var passwordInput = $('#password');
                if (passwordInput.prop('type') === 'password') {
                    passwordInput.prop('type', 'text');
                    $('#togglePassword').html('<i class="fa-light fa-eye-slash"></i>');
                } else {
                    passwordInput.prop('type', 'password');
                    $('#togglePassword').html('<i class="fa-light fa-eye"></i>');
                }
            });
        </script>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-gtEjrD/SeCtmISkJkNUaaKMoLD0//ElJ19smozuHV6z3Iehds+3Ulb9Bn9Plx0x4"
        crossorigin="anonymous"></script>
</body>

</html>




