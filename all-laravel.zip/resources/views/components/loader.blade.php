<div class="content-loader w-100 d-flex align-items-center justify-content-center">
    <div class="preloadTable">
        <div class="spinner-border"></div>
    </div>
</div>
