<div class="modal fade" id="{{ $modalId }}" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true" data-bs-backdrop="static">
    <div class="modal-dialog modal-dialog-centered {{ $modalxl}}">
        <div class="modal-content">
            <div class="modal-body position-relative">
                <button type="button" class="btn-icon-20 bg-danger rounded-3 btn-close-modal" onclick="closeFormModal('{{ $formId}}');" data-bs-dismiss="modal"><i class="fa-regular fa-circle-xmark"></i></button>
                {{ $slot }}
            </div>
        </div>
    </div>
</div>
