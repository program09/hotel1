<div class="imagen-preload position-absolute" id="prevloadimg" style="display: none;">
    <div class="spinner-border"></div>
</div>
<form class="row g-3 position-relative" id="editUserForm"> @csrf
    <h4 class="pb-3 col-lg-12 d-flex align-items-center justify-content-between">
        <span>Editar usuario: <span id="id-user-edit-txt"></span></span>
    </h4>
    <input type="hidden" id="userCadpo" name="userCadpo">
    <div class="col-lg-6 col-md-12 col-12 row g-3">
        <div class="col-lg-6 col-md-12 col-12">
            <label for="name-edit" class="form-label">Nombre *</label>
            <input type="text" class="form-control" id="name-edit" name="name-edit" placeholder="Nombre" required>
        </div>
        <div class="col-lg-6 col-md-12 col-sm-12 col-12">
            <label for="lastname-edit" class="form-label">Apellidos *</label>
            <input type="text" class="form-control" id="lastname-edit" name="lastname-edit" placeholder="Apellidos"
                required>
        </div>
        <div class="col-lg-6 col-md-12 col-sm-12  col-12">
            <label for="dni-edit" class="form-label">DNI *</label>
            <input type="text" class="form-control" id="dni-edit" name="dni-edit" placeholder="DNI" required>
        </div>
        <div class="col-lg-6 col-md-12 col-sm-12  col-12">
            <label for="sex-edit" class="form-label">Género *</label>
            <select id="sex-edit" name="sex-edit" class="form-select" aria-label="select habitacion">
                <option value="nodefinido" selected>Selecciona una opción</option>
                <option value="masculino">Masculino</option>
                <option value="femenino">Femenino</option>
            </select>
        </div>
        <div class="col-lg-6 col-md-12 col-sm-12  col-12">
            <label for="type-edit" class="form-label">Tipo *</label>
            <select name="type-edit" id="type-edit" class="form-select" aria-label="select habitacion">
                <option value="">Selecciona una opción</option>
                <option value="client" selected>Cliente</option>
                <option value="admin">Administrador</option>
            </select>
        </div>
        <div class="col-lg-6 col-md-12 col-sm-12  col-12">
            <label for="status-edit" class="form-label">Estado *</label>
            <select id="status-edit" name="status-edit" class="form-select" aria-label="select habitacion">
                <option value="" selected>Selecciona una opción</option>
                <option value="active">Activo</option>
                <option value="inactive">Inactivo</option>
            </select>
        </div>
        <div class="col-md-4 col-4">
            <label for="year-edit" class="form-label">Año *</label>
            <select id="year-edit" name="year-edit" class="form-select" aria-label="select habitacion">
                <option value="active" selected>Selecciona una opción</option>
            </select>
        </div>
        <div class="col-md-4 col-4">
            <label for="month-edit" class="form-label">Mes *</label>
            <select id="month-edit" name="month-edit" class="form-select">
                <option value="" selected>Selecciona una opción</option>
            </select>
        </div>
        <div class="col-md-4 col-4">
            <label for="day-edit" class="form-label">Día *</label>
            <select id="day-edit" name="day-edit" class="form-select">
                <option value="" selected>Selecciona una opción</option>
                <option value="01">01</option>
                <option value="02">02</option>
                <option value="03">03</option>
                <option value="04">04</option>
                <option value="05">05</option>
                <option value="06">06</option>
                <option value="07">07</option>
                <option value="08">08</option>
                <option value="09">09</option>
                <option value="10">10</option>
                <option value="11">11</option>
                <option value="12">12</option>
                <option value="13">13</option>
                <option value="14">14</option>
                <option value="15">15</option>
                <option value="16">16</option>
                <option value="17">17</option>
                <option value="18">18</option>
                <option value="19">19</option>
                <option value="20">20</option>
                <option value="21">21</option>
                <option value="22">22</option>
                <option value="23">23</option>
                <option value="24">24</option>
                <option value="25">25</option>
                <option value="26">26</option>
                <option value="27">27</option>
                <option value="28">28</option>
                <option value="29">29</option>
                <option value="30">30</option>
                <option value="31">31</option>
            </select>
        </div>
        <div class="col-md-12">
            <label for="email-edit" class="form-label">Correo electrónico *</label>
            <input type="text" class="form-control" id="email-edit" name="email-edit"
                placeholder="Correo electrónico" required>
        </div>
        <div class="col-lg-12 row justify-content-between g-3">
            <button type="submit" class="col-lg-4 col-md-12 col-12 btn btn-primary mb-2" id="btn-edit-all">Actualizar</button>
            <button type="button" class="col-lg-7 col-md-12 col-12 btn btn-warning mb-2" id="btnReserPass">Restablecer contraseña</button>
        </div>
    </div>

    <div class="col-lg-6 col-md-12 col-12">
        <div class="content-sect w-100">
            <form>
                <div class="w-100 d-flex justify-content-center p-2">
                    <div class="spinner-border" style="display: none;" id="preloadSendReset"></div>
                </div>
                <div class="alert-confirm" id="alert-confirs"></div>
                <p class="text-center">Actualizar la foto del usuario</p>
                <p class="text-center">Tamaño maximo: 5MB</p>
                <div class="content-photo">
                    <label for="photo-input" class="img-prev box-light">
                        <img id="user-photo-id" src="{{ asset('storage/images/user/user.png') }}" alt="">
                    </label>
                    <input type="file" id="photo-input" style="display: none;">

                </div>
                <div class="cont-button-form d-flex gap-4 align-items-center justify-content-center"
                    id="buttons-container">
                    <button class="text-center btn btn-primary" id="btnSavePhoto">Guardar</button>
                    <button class="text-center btn btn-danger" type="button">Cancelar</button>
                </div>
            </form>
        </div>
    </div>
</form>


@push('script_page')
    <script>
        $('#editUserForm').submit(function(e) {
            e.preventDefault();
            var token = $('meta[name="csrf-token"]').attr('content');
            var formData = $(this).serialize();
            $.ajax({
                type: "POST",
                url: "/user-update",
                data: formData,
                beforeSend: function() {
                    $('#prevloadimg').show();
                },
                success: function(response) {
                    console.log(response);
                    $('#prevloadimg').hide();
                    $('#alert-confirs').html(
                        '<div class="alert alert-warning alert-dismissible fade show" role="alert"><button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>' +
                        response.mensaje + '</div>');
                    $('#alert-confirs').show();
                    if (response.codigo === SUCCESS_CODE) {
                        listarUser();
                    }
                },
                error: function(xhr, status, error) {
                    $('#prevloadimg').hide();
                    var errors = xhr.responseJSON.errors;
                    if (errors) {
                        var errorMessage = '<ul>';
                        $.each(errors, function(key, value) {
                            errorMessage += '<li>' + value + '</li>';
                        });
                        errorMessage += '</ul>';
                        $('#alert-confirs').html(
                            '<div class="alert alert-danger alert-dismissible fade show" role="alert"><button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>' +
                            errorMessage + '</div>');
                    } else {
                        console.error('Error desconocido:', error);
                    }
                }
            });
        });
    </script>
    <script>
        userPhotoChange();
        sendResetPass();
        dateBirth('year-edit', 'month-edit', 'ASD');
    </script>
@endpush
