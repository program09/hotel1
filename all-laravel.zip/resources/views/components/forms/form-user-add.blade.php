<form class="row g-1" id="createUserForm"> @csrf
    <h4 class="pb-3">Crear nuevo usuario</h4>
    <hr>

    <div class="col-lg-6 col-md-12 col-sm-12 col-12 row g-2">
        <div class="col-md-5 col-12">
            <label for="name" class="form-label">Nombre *</label>
            <input type="text" class="form-control" id="name" name="name" placeholder="Nombre" required>
        </div>
        <div class="col-md-7 col-sm-12  col-12">
            <label for="lastname" class="form-label">Apellidos *</label>
            <input type="text" class="form-control" id="lastname" name="lastname" placeholder="Apellidos" required>
        </div>

        <div class="col-md-6 col-sm-12  col-12">
            <label for="dni" class="form-label">DNI *</label>
            <input type="text" class="form-control" id="dni" name="dni" placeholder="DNI" required>
        </div>
        <div class="col-md-6 col-sm-12  col-12">
            <label for="sex" class="form-label">Género *</label>
            <select id="sex" name="sex" class="form-select" aria-label="select habitacion">
                <option value="nodefinido" selected>Selecciona una opción</option>
                <option value="masculino">Masculino</option>
                <option value="femenino">Femenino</option>
            </select>
        </div>

        <div class="col-md-6 col-sm-12   col-12">
            <label for="type" class="form-label">Tipo *</label>
            <select name="type" id="type" class="form-select" aria-label="select habitacion">
                <option value="client">Selecciona una opción</option>
                <option value="client" selected>Cliente</option>
                <option value="admin">Administrador</option>
            </select>
        </div>
        <div class="col-md-6  col-sm-12  col-12">
            <label for="status" class="form-label">Estado *</label>
            <select id="status" name="status" class="form-select" aria-label="select habitacion">
                <option value="active">Selecciona una opción</option>
                <option value="active" selected>Activo</option>
                <option value="inactive">Inactivo</option>
            </select>
        </div>
        <div class="col-md-4 col-4">
            <label for="year" class="form-label">Año *</label>
            <select id="year" name="year" class="form-select" aria-label="select habitacion">
                <option value="active" selected>Selecciona una opción</option>
            </select>
        </div>
        <div class="col-md-4 col-4">
            <label for="month" class="form-label">Mes *</label>
            <select id="month" name="month" class="form-select" aria-label="select habitacion">
                <option value="" selected>Selecciona una opción</option>
            </select>
        </div>
        <div class="col-md-4 col-4">
            <label for="day" class="form-label">Día *</label>
            <select id="day" name="day" class="form-select" aria-label="select habitacion">
                <option value="" selected>Selecciona una opción</option>
            </select>
        </div>
    </div>

    <div class="col-lg-6 col-md-12 col-sm-12 col-12 row g-2">
        <div class="col-md-12">
            <label for="email" class="form-label">Correo electrónico *</label>
            <input type="text" class="form-control" id="email" name="email" placeholder="Correo electrónico"
                required>
        </div>
        <div class="col-md-12">
            <input class="form-check-input" type="checkbox" value="" id="email_validate" name="email_validate">
            <label class="form-check-label" for="email_validate">
                Enviar mensaje al correo para establecer contraseña
            </label>
        </div>
        <p class="">Se usará una contraseña por defecto (DNI) y el usuario podrá restablecerla en cualquier momento.</p>
        <div id="preload" style="display: none;"><div class="spinner-border"></div></div>
        <div class="alert-confirm" id="alert-confir"></div>
        <div class="col-12 d-flex align-items-center justify-content-end gap-3">
            <button class="btn btn-primary" type="submit" id="btn-add">Agregar trabajador</button>
            <button type="button" class="btn btn-danger" data-bs-dismiss="modal" onclick="closeFormModal('createUserForm');">Cerrar</button>
        </div>
    </div>

</form>



@push('script_page')
    <script>
        createUser();
        dateBirth('year', 'month', 'day');
    </script>
@endpush
