<div class="table-responsive">
    <table class="table table-borderless align-middle" id="flatTable">
        <thead>
            <tr>
                <th>Piso / Zona</th>
                <th>Estado</th>
                <th> </th>
            </tr>
        </thead>
        <tbody>
        </tbody>
    </table>
</div>


@push('script_page')
    <script>
        getFlatsAll();
        editFlats();
        editValLFlat()
        cancelFormEdit('formPisoAdd');
    </script>
@endpush
