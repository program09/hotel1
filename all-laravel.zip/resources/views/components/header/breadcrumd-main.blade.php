<div class="section-page br-15">
    <ul class="breadcrumb">
        <li class="breadcrumb-item"><a href="#">Monday</a></li>
        <li class="breadcrumb-item"><a href="#">Hoteles</a></li>
        <li class="breadcrumb-item active">{{ $title }}</li>
    </ul>
</div>
