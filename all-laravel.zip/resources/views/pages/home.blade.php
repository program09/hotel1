@section('title', 'Inicio')

<x-app-layout>
    @include('components.header.breadcrumd-main', ['title' => 'Inicio'])
    
    <div class="section-1">
        <div class="grid-1">
            <div class="grid-1-item box-light">
                <h6>Habitaciones</h6>
                <span class="status-data">12</span>
            </div>
            <div class="grid-1-item box-light">
                <h6>Habitaciones ocupadas</h6>
                <span class="status-data">12</span>
            </div>
            <div class="grid-1-item box-light">
                <h6>Habitaciones disponibles</h6>
                <span class="status-data">12</span>
            </div>
            <div class="grid-1-item box-light">
                <h6>Reservas activas</h6>
                <span class="status-data">12</span>
            </div>
            <div class="grid-1-item box-light">
                <h6>Reservas hoy</h6>
                <span class="status-data">12</span>
            </div>
            <div class="grid-1-item box-light">
                <h6>Huespedes</h6>
                <span class="status-data">12</span>
            </div>
        </div>
    </div>

    <div class="section-1">
        <div class="grid-2">
            <div class="grid-2-item box-light br-15 box-min">
                <h5>Habitaciones disponibles</h5>
                <hr>
                <div class="box-body">
                    <div class="table-responsive">
                        <table class="table table-borderless align-middle">
                            <thead>
                                <tr>
                                    <th>Habitación</th>
                                    <th>Tipo</th>
                                    <th> </th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td>#123</td>
                                    <td>
                                        <span class="badge bg-primary">Simple</span>
                                    </td>
                                    <td>
                                        <button class="btn-info-d"><i class="fa-light fa-eye"></i></button>
                                    </td>
                                </tr>
                                <tr>
                                    <td>#123</td>
                                    <td>
                                        <span class="badge bg-success">Doble</span>
                                    </td>
                                    <td>
                                        <button class="btn-info-d"><i class="fa-light fa-eye"></i></button>
                                    </td>
                                </tr>
                                <tr>
                                    <td>#123</td>
                                    <td>
                                        <span class="badge bg-warning">Triple</span>
                                    </td>
                                    <td>
                                        <button class="btn-info-d"><i class="fa-light fa-eye"></i></button>
                                    </td>
                                </tr>

                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            <div class="grid-2-item box-light br-15 box-min">
                <h5>Habitaciones ocupadas</h5>
                <hr>
                <div class="box-body">
                    <div class="table-responsive">
                        <table class="table table-borderless align-middle">
                            <thead>
                                <tr>
                                    <th>Habitación</th>
                                    <th>Detalles</th>
                                    <th> </th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td>#123</td>
                                    <td>
                                        <span class="badge bg-primary"><i class="fa-sharp fa-light fa-arrow-right"></i>
                                            10/12/2024
                                            10:20</span><br>
                                        <span class="badge bg-secondary"><i class="fa-sharp fa-light fa-arrow-left"></i>
                                            13/12/2024
                                            10:20</span>
                                    </td>
                                    <td>
                                        <button class="btn-info-d"><i class="fa-light fa-eye"></i></button>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            <div class="grid-2-item box-light br-15 box-min">
                <h5>Por finalizar</h5>
                <hr>
                <div class="box-body">
                    <div class="table-responsive">
                        <table class="table table-borderless align-middle">
                            <thead>
                                <tr>
                                    <th>Habitación</th>
                                    <th>Detalles</th>
                                    <th> </th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td>#123</td>
                                    <td>
                                        <span class="badge bg-primary"><i class="fa-sharp fa-light fa-arrow-right"></i>
                                            10/12/2024
                                            10:20</span><br>
                                        <span class="badge bg-secondary"><i class="fa-sharp fa-light fa-arrow-left"></i>
                                            13/12/2024
                                            10:20</span>
                                    </td>
                                    <td>
                                        <button class="btn-info-d"><i class="fa-light fa-eye"></i></button>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</x-app-layout>







