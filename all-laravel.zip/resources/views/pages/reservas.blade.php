@section('title', 'Reservas')

<x-app-layout>
    @include('components.header.breadcrumd-main', ['title' => 'Reservas'])

    <div class="section-1">
        <div class="box-light br-15 p-3 ">
            <div class="d-flex align-items-center gap-3" role="group" aria-label="Basic example">
                <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#modal1">Agregar</button>
                <button type="button" class="btn btn-warning">Reporte</button>
            </div>
        </div>
    </div>

    <div class="section-1">
        <div class="box-light p-3 br-15">
            <div class="responsive-x">
                <div id='calendar'></div>
            </div>
        </div>
    </div>

    <x-modal modalId="modal1">
        @include('components.forms.form-reservar')
    </x-modal>


    @push('script_page')
        <script src='https://cdn.jsdelivr.net/npm/fullcalendar@6.1.11/index.global.min.js'></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/fullcalendar/5.10.1/locales/es.min.js"></script>
        <script>
            document.addEventListener('DOMContentLoaded', function() {
                var calendarEl = document.getElementById('calendar');
                var calendar = new FullCalendar.Calendar(calendarEl, {
                    initialView: 'dayGridMonth',
                    locale: 'es',
                    editable: true,
                    droppable: true,
                    eventReceive: function(info) {
                        alert('Evento agregado: ' + info.event.title);
                    },
                    headerToolbar: {
                        left: 'prev,next today',
                        center: 'title',
                        right: 'dayGridMonth,timeGridWeek,timeGridDay',
                        end: 'listMonth'
                    },
                    select: function(info) {
                        alert('Fecha seleccionada: ' + info.start.toLocaleDateString('es', {
                            weekday: 'long',
                            year: 'numeric',
                            month: 'long',
                            day: 'numeric'
                        }));
                    }
                });
                calendar.render();
            });
            document.getElementById('agregarBtn').addEventListener('click', function() {
                // Obtener los valores seleccionados
                var habitacion = document.getElementById('habitacionSelect').value;
                var numeroSelect = document.getElementById('numeroSelect');
                var numero = numeroSelect.value;

                // Validar que se hayan seleccionado ambos valores
                if (habitacion && numero) {
                    // Verificar si el número ya existe en la tabla
                    var numerosEnTabla = Array.from(document.querySelectorAll('#tablaHabitaciones tbody tr')).map(row =>
                        row.cells[0].textContent.match(/\d+/g)[0]);
                    if (numerosEnTabla.includes(numero)) {
                        // Mostrar una alerta de Bootstrap si el número ya existe
                        var alerta = `<div id="alerta" class="alert alert-warning alert-dismissible fade show" role="alert">
                                La habitación número ${numero} está en la lista.
                                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                            </div>`;

                        document.getElementById('alertContainer').innerHTML = alerta;
                        numeroSelect.value = "";
                        // Eliminar la alerta después de 5 segundos
                        setTimeout(function() {
                            var alertaElement = document.getElementById('alerta');
                            if (alertaElement) {
                                alertaElement.remove();
                            }
                        }, 5000);
                    } else {
                        // Crear una nueva fila para la tabla
                        var newRow = document.createElement('tr');
                        newRow.innerHTML = `
                    <td>#${numero} <span class="badge bg-primary">${habitacion}</span></td>
                    <td>s/ 120</td>
                    <td>
                        <button class="btn btn-danger btn-sm"><i class="fa-regular fa-trash-can"></i></button>
                    </td>
                `;

                        // Agregar la nueva fila a la tabla
                        document.getElementById('tablaHabitaciones').getElementsByTagName('tbody')[0].appendChild(
                            newRow);

                        // Limpiar el valor del select de número para eliminar la opción seleccionada
                        numeroSelect.value = "";
                    }
                } else {
                    alert('Por favor seleccione una habitación y un número.');
                }
            });
        </script>
    @endpush

</x-app-layout>
