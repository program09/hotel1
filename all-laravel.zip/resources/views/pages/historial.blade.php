@section('title', 'Historial')

<x-app-layout>
    @include('components.header.breadcrumd-main', ['title' => 'Historial'])

    <div class="section-1">
        <div class="box-light br-15 p-3 ">
            <div class="d-flex align-items-center gap-3" role="group" aria-label="Basic example">
                <button type="button" class="btn btn-warning">Reporte</button>
            </div>
        </div>
    </div>

    <div class="section-1">
        <div class="box-light p-3 br-15">
            <div class="table-responsive">
                <table class="table table-borderless align-middle">
                    <thead>
                        <tr>
                            <th>Cliente</th>
                            <th>DNI / RUC</th>
                            <th>Entrada</th>
                            <th>Salida</th>
                            <th>Estado</th>
                            <th> </th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td>Juan</td>
                            <td>98765432</td>
                            <td>10/08/2024 - 20:45</td>
                            <td><span class="badge bg-success">Hospedado</span>
                            </td>
                            <td>
                                <button class="btn btn-primary btn-sm"><i
                                        class="fa-light fa-pen-to-square"></i></button>
                                <button class="btn btn-danger btn-sm"><i class="fa-light fa-trash-can"></i></button>
                            </td>
                        </tr>
                        <tr>
                            <td>Juan</td>
                            <td>98765432</td>
                            <td>10/08/2024 - 20:45</td>
                            <td><span class="badge bg-warning">En espera</span>
                            </td>
                            <td>
                                <button class="btn btn-primary btn-sm"><i
                                        class="fa-light fa-pen-to-square"></i></button>
                                <button class="btn btn-danger btn-sm"><i class="fa-light fa-trash-can"></i></button>
                            </td>
                        </tr>
                        <tr>
                            <td>Juan</td>
                            <td>98765432</td>
                            <td>10/08/2024 - 20:45</td>
                            <td><span class="badge bg-danger">Finalizado</span>
                            </td>
                            <td>
                                <button class="btn btn-primary btn-sm"><i
                                        class="fa-light fa-pen-to-square"></i></button>
                                <button class="btn btn-danger btn-sm"><i class="fa-light fa-trash-can"></i></button>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <x-modaprueba>
        aquí va el formulario
    </x-modaprueba>

</x-app-layout>
