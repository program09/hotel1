@section('title', 'Trabajadores')

<x-app-layout>
    @include('components.header.breadcrumd-main', ['title' => 'Trabajadores'])

    <div class="section-1">
        <div class="box-light br-15 p-3 ">
            <div class="d-flex align-items-center gap-3" role="group" aria-label="Basic example">
                <button type="button" class="btn btn-primary" data-bs-toggle="modal"
                    data-bs-target="#modal1">Agregar</button>
                <button type="button" class="btn btn-warning">Reporte</button>
            </div>
        </div>
    </div>

    <div class="section-1">
        <div class="box-light p-3 br-15">
            <div class="table-responsive">
                <table class="table table-borderless align-middle" id="userTable">
                    <thead>
                        <tr>
                            <th>DNI</th>
                            <th>Trabajador</th>
                            <th>Correo</th>
                            <th>Género</th>
                            <th>Nacimiento</th>
                            <th>Tipo</th>
                            <th>Estado</th>
                            <th> </th>
                        </tr>
                    </thead>
                    <tbody>
                    </tbody>
                </table>
            </div>
            <x-loader></x-loader>
        </div>
    </div>

    <x-modal modalId="modal1" modalxl="modal-xl" formId="createUserForm">
        @include('components.forms.form-user-add')
    </x-modal>

    <x-modal modalId="modal2" modalxl="modal-xl" formId="editUserForm">
        @include('components.forms.form-user-edit')
    </x-modal>

    @push('script_page')
    <script>
        listarUser();
    </script>
    @endpush
</x-app-layout>
