@section('title', 'Habitaciones')
<x-app-layout>

    @include('components.header.breadcrumd-main', ['title' => 'Habitaciones'])

    <div class="section-1">
        <div class="box-light br-15 p-3">
            <div class="d-flex align-items-center gap-3" role="group" aria-label="Basic example">
                <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#modal1">Agregar</button>
                <button type="button" class="btn btn-success" data-bs-toggle="modal" data-bs-target="#modal2">Pisos</button>
                <button type="button" class="btn btn-warning" data-bs-toggle="modal" data-bs-target="#modal3">Tipos</button>
            </div>
        </div>
    </div>

    <x-modal modalId="modal1" modalxl="modal-md" formId="formRoom">
        @include('components.forms.form-room-add')
    </x-modal>
    <x-modal modalId="modal2" modalxl="modal-md" formId="formPiso">
        @include('components.forms.form-piso-add') <hr>
        @include('components.tables.table-piso')
    </x-modal>
    <x-modal modalId="modal3" modalxl="modal-md" formId="formTipo">
        @include('components.forms.form-tipo-room') <hr>
        @include('components.tables.table-tipo-room')
    </x-modal>

    <div class="section-1">
        <div class="title-section box-light br-15 p-3 mb-4">
            <!-- Nav pills -->
            <ul class="nav nav-pills">
                <li class="nav-item">
                    <a class="nav-link active" data-bs-toggle="pill" href="#home">Piso 1</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" data-bs-toggle="pill" href="#menu1">Piso 2</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" data-bs-toggle="pill" href="#menu2">Piso 3</a>
                </li>
            </ul>
        </div>

        <!-- Tab panes -->
        <div class="tab-content">
            <div class="tab-pane active" id="home">
                <div class="grid-1">
                    <div class="grid-1-item box-light br-15 box-min d-block">
                        <div class="photo-room  position-relative">
                            <div class="status-room position-absolute m-1">
                                <span class="badge bg-danger badge-1">Ocupado</span><br>
                                <span class="badge bg-primary badge-1">Doble</span><br>
                                <span class="badge bg-secondary badge-1">s/ 40 x noche</span>
                            </div>

                            <img src="https://villaleonenairobi.com/static/images/roombg.jpg" alt="">
                        </div>
                        <div class="info-room mt-2">
                            <p>Habitación: <span class="">102</span></p>
                            <button class="w-100 btn btn-success mt-2">Mostrar</button>
                        </div>
                    </div>
                    <div class="grid-1-item box-light br-15 box-min d-block">
                        <div class="photo-room  position-relative">
                            <div class="status-room position-absolute m-1">
                                <span class="badge bg-warning badge-1">Libre</span><br>
                                <span class="badge bg-success badge-1">Simple</span><br>
                                <span class="badge bg-secondary badge-1">s/ 20 x noche</span>
                            </div>

                            <img src="https://villaleonenairobi.com/static/images/roombg.jpg" alt="">
                        </div>
                        <div class="info-room mt-2">
                            <p>Habitación: <span class="">102</span></p>
                            <button class="w-100 btn btn-success mt-2">Mostrar</button>
                        </div>
                    </div>
                </div>
            </div>
            <div class="tab-pane fade" id="menu1">
                <div class="grid-1">
                    <div class="grid-1-item box-light br-15 box-min d-block">
                        <div class="photo-room  position-relative">
                            <div class="status-room position-absolute m-1">
                                <span class="badge bg-danger badge-1">Ocupado</span><br>
                                <span class="badge bg-primary badge-1">Doble</span><br>
                                <span class="badge bg-secondary badge-1">s/ 40 x noche</span>
                            </div>

                            <img src="https://villaleonenairobi.com/static/images/roombg.jpg" alt="">
                        </div>
                        <div class="info-room mt-2">
                            <p>Habitación: <span class="">102</span></p>
                            <button class="w-100 btn btn-success mt-2">Mostrar</button>
                        </div>
                    </div>
                    <div class="grid-1-item box-light br-15 box-min d-block">
                        <div class="photo-room  position-relative">
                            <div class="status-room position-absolute m-1">
                                <span class="badge bg-warning badge-1">Libre</span><br>
                                <span class="badge bg-success badge-1">Simple</span><br>
                                <span class="badge bg-secondary badge-1">s/ 20 x noche</span>
                            </div>

                            <img src="https://villaleonenairobi.com/static/images/roombg.jpg" alt="">
                        </div>
                        <div class="info-room mt-2">
                            <p>Habitación: <span class="">102</span></p>
                            <button class="w-100 btn btn-success mt-2">Mostrar</button>
                        </div>
                    </div>
                </div>
            </div>
            <div class="tab-pane fade" id="menu2">
                <div class="grid-1">
                    <div class="grid-1-item box-light br-15 box-min d-block">
                        <div class="photo-room  position-relative">
                            <div class="status-room position-absolute m-1">
                                <span class="badge bg-danger badge-1">Ocupado</span><br>
                                <span class="badge bg-primary badge-1">Doble</span><br>
                                <span class="badge bg-secondary badge-1">s/ 40 x noche</span>
                            </div>

                            <img src="https://villaleonenairobi.com/static/images/roombg.jpg" alt="">
                        </div>
                        <div class="info-room mt-2">
                            <p>Habitación: <span class="">102</span></p>
                            <button class="w-100 btn btn-success mt-2">Mostrar</button>
                        </div>
                    </div>
                    <div class="grid-1-item box-light br-15 box-min d-block">
                        <div class="photo-room  position-relative">
                            <div class="status-room position-absolute m-1">
                                <span class="badge bg-warning badge-1">Libre</span><br>
                                <span class="badge bg-success badge-1">Simple</span><br>
                                <span class="badge bg-secondary badge-1">s/ 20 x noche</span>
                            </div>

                            <img src="https://villaleonenairobi.com/static/images/roombg.jpg" alt="">
                        </div>
                        <div class="info-room mt-2">
                            <p>Habitación: <span class="">102</span></p>
                            <button class="w-100 btn btn-success mt-2">Mostrar</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>



    </div>



    @push('script_page')

    @endpush

</x-app-layout>
