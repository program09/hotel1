<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\QueryException;

class Typeroom extends Model
{
    use HasFactory;
    protected $table = 'typerooms';
    protected $fillable = ['id','type','status',];

    public static function showAll(){
        try {
            $list = self::all();
            return $list;
        } catch (\Exception $e) {
            return 'Ocurrió un error al obtener los datos.';
        }
    }

    public static function newType($type, $status)
    {
        try {
            User::userCheck();
            return static::create([
                'piso' => $type,
                'status' => $status,
            ]);
        } catch (QueryException $e) {
            return $e->getMessage();
        }
    }

    public static function deleteType($id)
    {
        try {
            User::userCheck();
            $deletedRows = Typeroom::destroy($id);
            if ($deletedRows > 0) {
                return 'Eliminado';
            } else {
                return 'Error, no se pudo eliminar';
            }
        } catch (QueryException $e) {
            return $e->getMessage();
        }
    }

}
