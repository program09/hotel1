<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\QueryException;

class Flats extends Model
{
    use HasFactory;
    protected $table = 'flats';
    protected $fillable = ['id', 'piso', 'status',];
    public static function newFlat($piso, $status)
    {
        try {
            User::userCheck();
            return static::create([
                'piso' => $piso,
                'status' => $status,
            ]);
        } catch (QueryException $e) {
            return $e->getMessage();
        }
    }

    public static function deleteFlat($id)
    {
        try {
            User::userCheck();
            $deletedRows = Flats::destroy($id);
            if ($deletedRows > 0) {
                return 'Eliminado';
            } else {
                return 'Error, no se pudo eliminar';
            }
        } catch (QueryException $e) {
            return $e->getMessage();
        }
    }

    public static function updateFlat($id, $piso, $status)
    {
        try {
            User::userCheck();
            $flat = self::findOrFail($id);
            $flat->update([
                'piso' => $piso,
                'status' => $status,
            ]);
            if ($flat) {
                return 'Actualizado';
            } else {
                return 'Error, no se pudo eliminar';
            }
        } catch (QueryException $e) {
            return $e->getMessage();
        }
    }
}
