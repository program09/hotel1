<?php



namespace App\Notifications;

use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Notifications\Messages\MailMessage;
use Illuminate\Notifications\Notification;
use Illuminate\Support\Facades\URL;

class CustomResetPasswordNotification extends Notification
{
    use Queueable;
    protected $token;

    public function __construct($token)
    {
        $this->token = $token;
    }


    public function via($notifiable)
    {
        return ['mail'];
    }

    public function toMail($notifiable)
    {
        return (new MailMessage)
            ->subject('Solicitud de restablecimiento de contraseña')
            ->line('Recibes este correo porque hemos recibido una solicitud para restablecer la contraseña de tu cuenta.')
            ->action('Restablecer Contraseña', URL::to('/reset-password/'.$this->token.'?email='.urlencode($notifiable->email)))
            ->line('Este enlace de restablecimiento de contraseña caducará en 60 minutos.')
            ->salutation('Saludos, ' . $notifiable->name)
            ->line('Si tienes problemas para hacer clic en el botón "Restablecer Contraseña", copia y pega la siguiente URL en tu navegador web: '.URL::to('/reset-password/'.$this->token.'?email='.urlencode($notifiable->email)));
    }
}


