<?php

namespace App\Http\Controllers;

use App\Models\Typeroom;
use Illuminate\Http\Request;

class TyperoomController extends Controller
{

    public function showAll(){
        $lista = Typeroom::showAll();
        return response()->json($lista);
    }
    public function createType(Request $request){
        return 0;
    }

    public function deleteTypeRoom(Request $request){
        $id = $request->input('dataId');
        $delete = Typeroom::deleteType($id);
        return response()->json(['message' => $delete, 'codigo' => 1]);
    }
}
