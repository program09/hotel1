<?php


namespace App\Http\Controllers;



use App\Models\Flats;
use Illuminate\Http\Request;

class FlatController extends Controller
{
    public function listarflat()
    {
        $flat = Flats::all();
        return response()->json($flat);
    }

    public function createflat(Request $request)
    {
        try {
            $request->validate([
                'name-flat' => 'required|string|max:30',
                'status-flat' => 'required|string|in:active,inactive',
            ], [
                'name-flat.max' => 'El campo piso/zona debe tener maximo 30 caracteres.',
                'status-flat.in' => 'El estado debe ser "Activo" o "Inactivo".',
            ]);

            Flats::newFlat($request->input('name-flat'), $request->input('status-flat'));
            return response()->json(['message' => 'La información ha sido guardada', 'codigo' => 1]);

        }  catch (\Illuminate\Validation\ValidationException $e) {
            $errors = $e->validator->errors()->all();
            return response()->json(['errors' => $errors, 'codigo' => 0], 422);
        }
    }

    public function deleteflat(Request $request){

        $id = $request->input('dataId');
        $flat = Flats::deleteFlat($id);
        return response()->json(['message' => $flat, 'codigo' => 1]);
    }

    public function editFlat(Request $request, $id){
        $piso = $request->input('name-flat');
        $status = $request->input('status-flat');
        $flat = Flats::updateFlat($id,$piso,$status);
        return response()->json(['message' => $flat, 'codigo' => 1]);
    }
}
