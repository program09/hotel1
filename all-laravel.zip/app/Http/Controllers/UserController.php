<?php

namespace App\Http\Controllers;

use App\Models\User;
use App\Notifications\CustomResetPasswordNotification;
use Dotenv\Exception\ValidationException;
use Dotenv\Validator;
use Exception;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Password;
use PhpParser\Node\Stmt\TryCatch;
use Illuminate\Support\Facades\Storage;
use Intervention\Image\ImageManagerStatic as Image;


class UserController extends Controller
{
    public function listarUser()
    {
        $userId = Auth::id();
        $lista = User::where('id', '!=', $userId)->get();
        return response()->json($lista);
    }

    public function createUser(Request $request)
    {
        try {
            if (!auth()->check()) {
                return redirect()->route('login')->with('error', 'Debes iniciar sesión para realizar esta acción.');
            }
            $request->validate([
                'dni' => 'required|string|unique:users,dni|digits:8',
                'type' => 'required|in:client,admin',
                'status' => 'required|in:active,inactive',
                'sex' => 'required|in:masculino,femenino',
                'email' => 'required|email|unique:users,email',
            ], [
                'dni.unique' => 'El usuario con DNI ' . $request->input('dni') . ' ya existe.',
                'dni.digits' => 'El DNI debe tener 8 dígitos.',
                'type.in' => 'El tipo de cliente debe ser "cliente" o "administrador".',
                'status.in' => 'El estado debe ser "activo" o "inactivo".',
                'sex.in' => 'El género debe ser "masculino" o "femenino".',
                'email.unique' => 'El correo electrónico ya está en uso.',
                'email.email' => 'El campo correo "' . $request->input('email') . '" no es válido',
            ]);
            $name = $request->input('name');
            $lastname = $request->input('lastname');
            $dni = $request->input('dni');
            $sex = $request->input('sex');
            $type = $request->input('type');
            $status = $request->input('status');
            $year = $request->input('year');
            $month = $request->input('month');
            $day = $request->input('day');
            $email = $request->input('email');
            $emailValidate = $request->input('email_validate');
            $birthdate = $year . '/' . $month . '/' . $day;
            $user = new User();
            $password = $this->generateRandomPassword();
            $user->name = $name;
            $user->lastname = $lastname;
            $user->dni = $dni;
            $user->sex = $sex;
            $user->type = $type;
            $user->status = $status;
            $user->birth = $birthdate;
            $user->email = $email;
            $user->password = Hash::make($password);
            $user->save();
            $mensaje = "";
            if ($emailValidate === 'true' && $user->exists) {
                $status = User::sendResetLink($email);
                if ($status  === true) {
                    $mensaje = 'Se envió un correo para restablecer la contraseña a la dirección del usuario.';
                } else {
                    $mensaje = 'No se pudo enviar el correo para restablecer la contraseña. Inténtelo más tarde.';
                }
            } else {
                $mensaje = 'El usuario se creó correctamente. Podrá restablecer su contraseña en cualquier momento.';
            }
            return response()->json(['mensaje' => $mensaje, 'codigo' => 1]);
        } catch (\Illuminate\Validation\ValidationException $e) {
            $errors = $e->validator->errors()->all();
            return response()->json(['errors' => $errors, 'codigo' => 0], 422);
        }
    }

    private function generateRandomPassword($length = 8)
    {
        $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
        $password = '';
        for ($i = 0; $i < $length; $i++) {
            $index = rand(0, strlen($characters) - 1);
            $password .= $characters[$index];
        }
        return $password;
    }

    public function deleteUser(Request $request)
    {
        if (!auth()->check()) {
            return redirect()->route('login')->with('error', 'Debes iniciar sesión para realizar esta acción.');
        }
        try {
            $id = $request->input('id');
            $user = User::findOrFail($id);
            $user->delete();
            return response()->json(['success' => true, 'message' => 'Usuario eliminado correctamente']);
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'message' => 'Error al eliminar el usuario: ' . $e->getMessage()]);
        }
    }

    public function showUser($id)
    {
        $user = User::find($id);
        return $user;
    }
    public function reserUser(Request $email)
    {
        $email = $email->user;
        $user = User::sendResetLink($email);
        return "mensaje enviado" . $user;
    }

    public function photoUserZ(Request $request)
    {
    }

    public function photoUser(Request $request)
    {
        try {
            if (!auth()->check()) {
                return redirect()->route('login')->with('error', 'Debes iniciar sesión para realizar esta acción.');
            }
            $request->validate([
                'photo' => 'required|image|mimes:jpeg,png|max:5120',
            ], [
                'photo.image' => 'El archivo debe ser una imagen.',
                'photo.mimes' => 'El archivo debe ser de tipo JPEG, PNG',
                'photo.max' => 'El tamaño del archivo no puede ser mayor a 5MB.',
            ]);
            $image = $request->file('photo');
            $imageName = 'U' . uniqid();
            $extension = $image->getClientOriginalExtension();
            $imageNameWithExtension = $imageName . '.' . $extension;
            $user = User::findOrFail($request->user);
            if ($user->photo !== 'user.png') {
                Storage::delete('public/images/user/' . $user->photo);
                $image->storeAs('public/images/user', $imageNameWithExtension);
                if (Storage::exists('public/images/user/' . $imageNameWithExtension)) {
                    $user->photo = $imageNameWithExtension;
                    $user->save();
                } else {
                    return response()->json(['errors' => 'Error, intente más tarde.', 'codigo' => 0], 422);
                }
            }else if($user->photo === 'user.png') {
                $image->storeAs('public/images/user', $imageNameWithExtension);
                if (Storage::exists('public/images/user/' . $imageNameWithExtension)) {
                    $user->photo = $imageNameWithExtension;
                    $user->save();
                } else {
                    return response()->json(['errors' => 'Error, intente más tarde.', 'codigo' => 0], 422);
                }
            }

            return response()->json(['errors' => 'no hay errores', 'codigo' => 1]);
        } catch (\Illuminate\Validation\ValidationException $e) {
            $errors = $e->validator->errors()->all();
            return response()->json(['errors' => $errors, 'codigo' => 0], 422);
        }
    }

    public function updateUser(Request $request)
    {
        try {
            $id = $request->input('userCadpo');
            if (!auth()->check()) {
                return redirect()->route('login')->with('error', 'Debes iniciar sesión para realizar esta acción.');
            }
            $request->validate([
                'dni-edit' => 'required|string|digits:8|unique:users,dni,' . $id,
                'type-edit' => 'required|in:client,admin',
                'status-edit' => 'required|in:active,inactive',
                'sex-edit' => 'required|in:masculino,femenino',
                'email-edit' => 'required|email|unique:users,email,' . $id,
            ], [
                'dni-edit.unique' => 'El DNI ' . $request->input('dni-edit') . ' ya está en uso por otro usuario.',
                'dni-edit.digits' => 'El DNI debe tener 8 dígitos.',
                'type-edit.in' => 'El tipo de cliente debe ser "cliente" o "administrador".',
                'status-edit.in' => 'El estado debe ser "activo" o "inactivo".',
                'sex-edit.in' => 'El género debe ser "masculino" o "femenino".',
                'email-edit.unique' => 'El correo electrónico ya está en uso.',
                'email-edit.email' => 'El campo correo "' . $request->input('email-edit') . '" no es válido',
            ]);

            $user = User::findOrFail($id);
            $name = $request->input('name-edit');
            $lastname = $request->input('lastname-edit');
            $dni = $request->input('dni-edit');
            $sex = $request->input('sex-edit');
            $type = $request->input('type-edit');
            $status = $request->input('status-edit');
            $year = $request->input('year-edit');
            $month = $request->input('month-edit');
            $day = $request->input('day-edit');
            $email = $request->input('email-edit');
            $birthdate = $year . '/' . $month . '/' . $day;
            $user->name = $name;
            $user->lastname = $lastname;
            $user->dni = $dni;
            $user->sex = $sex;
            $user->type = $type;
            $user->status = $status;
            $user->birth = $birthdate;
            $user->email = $email;
            $user->save();
            return response()->json(['mensaje' => 'Se modificó los datos del usuario', 'codigo' => 1]);

        } catch (\Illuminate\Validation\ValidationException $e) {
            $errors = $e->validator->errors()->all();
            return response()->json(['errors' => $errors, 'codigo' => 0], 422);
        }
    }
}
