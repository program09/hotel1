var token = $('meta[name="csrf-token"]').attr('content');
const SUCCESS_CODE = 1;
const ERROR_CODE = 0;

function crearFilaUsuario(user) {
    var badgeClass = user.status === 'active' ? 'bg-success' : 'bg-danger';
    var badgeText = user.status === 'active' ? 'Activo' : 'Inactivo';
    var badgeClassa = user.type === 'client' ? 'bg-info' : 'bg-warning';
    var badgeTexta = user.type === 'client' ? 'Client' : 'Admin';

    var badgeClassax = user.sex === 'masculino' ? 'bg-warning' : 'bg-primary';
    var badgeTextax = user.sex === 'masculino' ? 'M' : 'F';

    var row = '<tr id="fila-' + user.dni + '"> ' +
        '<td>' + user.dni + '</td>' +
        '<td>' + user.name + ' ' + user.lastname + '</td>' +
        '<td>' + user.email + '</td>' +
        '<td><span class="badge ' + badgeClassax + '">' + badgeTextax + '</span></td>' +
        '<td>' + user.birth + '</td>' +
        '<td><span class="badge ' + badgeClassa + '">' + badgeTexta + '</span><span class="d-none">' + user.sex + '</span></td>' +
        '<td><span class="badge ' + badgeClass + '">' + badgeText + '</span></td>' +
        '<td>' +
        '<button class="btn btn-primary btn-sm btn-edit"  data-id="' + user.id + '" ><i class="fa-light fa-pen-to-square"></i></button>' +
        '<button class="btn btn-danger btn-sm btn-eliminar" data-id="' + user.id + '" data-dni="' + user.dni + '"><i class="fa-light fa-trash-can"></i></button>' +
        '</td>' +
        '</tr>';
    return row;
}

function listarUser() {
    $.ajax({
        type: 'get',
        url: '/user-all',
        beforeSend: function () {
            $('.preloadTable').show();
        },
        success: function (response) {
            destruirTabla();
            $('#userTable tbody').empty();
            response.forEach(function (user) {
                var row = crearFilaUsuario(user);
                $('#userTable tbody').append(row);
            });
            $('.preloadTable').hide();
            if (!$.fn.DataTable.isDataTable('.table')) {
                datatableCreate();
            }
        },
        error: function (xhr, status, error) {
            console.error('Error en la solicitud AJAX:', error);
        }
    });
}

function createUser() {
    $('#createUserForm').submit(function (e) {
        e.preventDefault();
        var formData = $(this).serialize();
        var isChecked = $('#email_validate').is(':checked');
        if (isChecked) {
            formData += '&email_validate=true';
        } else {
            formData += '&email_validate=false';
        }
        $.ajax({
            type: "POST",
            url: "/user-add",
            data: formData,
            beforeSend: function () {
                $('#preload').show();
            },
            success: function (response) {
                handleSuccessResponse(response);
            },
            error: function (xhr, status, error) {
                handleErrorResponse(xhr);
            }
        });
    });
}

function handleSuccessResponse(response) {

    alertB5('alert-confir', 'warning', response.mensaje);
    $('#alert-confir').show();
    $('#preload').hide();
    if (response.codigo === SUCCESS_CODE) {
        listarUser();
        closeForm('createUserForm');
    }
}

function handleErrorResponse(xhr) {
    $('#preload').hide();
    var errors = xhr.responseJSON.errors;
    if (errors) {
        var errorMessage = '<ul>';
        $.each(errors, function (key, value) {
            errorMessage += '<li>' + value + '</li>';
        });
        errorMessage += '</ul>';
        alertB5('alert-confir', 'danger', errorMessage);
    } else {
        console.error('Error desconocido:', error);
    }
}

$(document).on('click', '.btn-eliminar', function () {
    var idUsuario = $(this).data('id');
    var dniUsuario = $(this).data('dni');
    var filaUsuario = $(this).closest('tr').attr('id');
    mostrarAlertaEliminar(idUsuario, dniUsuario)
});

function mostrarAlertaEliminar(idUsuario, dniUsuario) {
    Swal.fire({
        title: '¿Eliminar usuario ' + dniUsuario + '?',
        text: "Esta acción no se puede deshacer.",
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Sí, eliminar',
        cancelButtonText: 'Cancelar'
    }).then((result) => {
        if (result.isConfirmed) {
            eliminarUsuario(idUsuario);
            Swal.fire({
                icon: 'success',
                title: 'Eliminado',
                text: 'Se eliminó al usuario: ' + idUsuario
            });
        }
    });
}

function eliminarUsuario(idUsuario) {
    var token = $('meta[name="csrf-token"]').attr('content');
    $.ajax({
        type: 'POST',
        url: '/user-delete',
        data: {
            id: idUsuario,
            _token: token
        },
        success: function (response) {
            listarUser();
        },
        error: function (xhr, status, error) {
            console.error(xhr.responseText);
        }
    });
}

$(document).on('click', '.btn-edit', function () {
    var idUsuario = $(this).data('id');
    userDetaill(idUsuario, 'modal2');
});

function showModal(id) {
    $('#' + id).modal('show');
}

function userDetaill(codigo, modal) {
    showModal(modal);
    $.ajax({
        type: "get",
        url: "/user-show/" + codigo,
        beforeSend: function () {
            $('#prevloadimg').show();
        },
        success: function (response) {
            asignarVal(response);
        }
    });
}

function asignarVal(response) {
    $('#userCadpo').val(response.id);
    $('#name-edit').val(response.name);
    $('#lastname-edit').val(response.lastname);
    $('#dni-edit').val(response.dni);
    $('#sex-edit').val(response.sex);
    $('#type-edit').val(response.type);
    $('#status-edit').val(response.status);
    $('#email-edit').val(response.email);
    $('#id-user-edit-txt').text(response.dni);
    const birthDate = new Date(response.birth);
    const year = birthDate.getFullYear();
    const month = birthDate.getMonth() + 1;
    const fecha = response.birth;
    const partes = fecha.split("-");
    const day = partes[2];
    $('#year-edit').val(year);
    $('#month-edit').val(month);
    $('#day-edit').val(day);
    $('#user-photo-id').attr('src', "storage/images/user/" + response.photo);
    $('#prevloadimg').hide();
}

function userPhotoChange() {
    var originalImageUrl = $('#user-photo-id').attr('src');
    var cont = 0;
    $('#buttons-container button').hide();
    $('#photo-input').change(function () {
        if (this.files && this.files[0]) {
            var reader = new FileReader();
            reader.onload = function (e) {
                $('#user-photo-id').attr('src', e.target.result);
                $('#buttons-container button').show();
            }
            reader.readAsDataURL(this.files[0]);
        }
        if (cont === 0) {
            originalImageUrl = $('#user-photo-id').attr('src');
            cont++;
        }
    });
    $('#buttons-container .btn-danger').click(function () {
        $('#user-photo-id').attr('src', originalImageUrl);
        $('#buttons-container button').hide();
        $('#photo-input').val('');
    });
    $('#btnSavePhoto').click(function (e) {
        e.preventDefault();
        var formData = new FormData();
        var fileInput = document.getElementById('photo-input');
        var file = fileInput.files[0];
        var user = $('#userCadpo').val();
        formData.append('photo', file);
        formData.append('_token', token);
        formData.append('user', user);
        $.ajax({
            type: "post",
            url: "/user-photo",
            data: formData,
            processData: false,
            contentType: false,
            beforeSend: function () {
                $('#preloadSendReset').show();
            },
            success: function (response) {
                $('#preloadSendReset').hide();
                $('#buttons-container button').hide();
                console.log(response)
                $('#alert-confirs').html(' ');
            },
            error: function (xhr, status, error) {
                $('#preloadSendReset').hide();
                var errors = xhr.responseJSON.errors;
                if (errors) {
                    var errorMessage = '<ul>';
                    $.each(errors, function (key, value) {
                        errorMessage += '<li>' + value + '</li>';
                    });
                    errorMessage += '</ul>';
                    alertB5('alert-confirs', 'danger', errorMessage);
                } else {
                    console.error('Error desconocido:', error);
                }
            }
        });
    });
}

function sendResetPass() {
    $('#btnReserPass').click(function () {
        $user = $('#email-edit').val();
        Swal.fire({
            title: '¿Enviar enlace para restablecer contraseña?',
            text: "Se enviará un enlace a: " + $user,
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Enviar',
            cancelButtonText: 'Cancelar'
        }).then((result) => {
            if (result.isConfirmed) {
                $.ajax({
                    type: "post",
                    url: "/user-reset",
                    data: {
                        '_token': token,
                        'user': $user
                    },
                    beforeSend: function () {
                        $('#preloadSendReset').show();
                    },
                    success: function (data) {
                        $('#preloadSendReset').hide();
                        swal1('success', 'Enlace enviado',
                            'El enlace estará vigente por 60 minutos');
                    }
                });
            }
        });
    })
}


function getFlatsAll() {
    $.ajax({
        type: "get",
        url: "/flat-all",
        beforeSend: function () {
            $('#preloadTablePisos').show();
        },
        success: function (response) {
            $('#flatTable tbody').empty();
            $('#preloadTablePisos').hide()
            $.each(response, function (index, flat) {
                var badgeClass = flat.status === 'active' ? 'bg-success' : 'bg-danger';
                var row = '<tr>' +
                    '<td>' + flat.piso + '</td>' +
                    '<td><span class="badge ' + badgeClass + '">' + flat.status +
                    '</span></td>' +
                    '<td>' +
                    '<button class="btn btn-primary btn-sm btn-edit-piso" data-id="' + flat.id + '"><i class="fa-light fa-pen-to-square"></i></button>' +
                    '<button class="btn btn-danger btn-sm btn-eliminar-piso" data-id="' + flat.id + '"><i class="fa-light fa-trash-can"></i></button>' +
                    '</td>' +
                    '</tr>';
                $('#flatTable tbody').append(row);
            });
            $('.btn-eliminar-piso').click(function (e) {
                e.preventDefault();
                msgAlertDelete(this);
            });

        }
    });
}

function msgAlertDelete(btn) {
    var dataId = $(btn).data('id');
    console.log('ID del elemento:', dataId);
    $.ajax({
        type: "POST",
        url: "/flat-delete",
        data: {
            dataId: dataId,
            _token: token
        },
        beforeSend: function () {
            $('#preloadTablePisos').show();
        },
        success: function (response) {
            console.log(response.message);
            getFlatsAll();
            $('#preloadTablePisos').hide()
            alertB5('alerts_piso', 'success', response.message);
        },
        error: function (xhr, status, error) {
            console.error('Error al eliminar el flat:', error);
            $('#preloadTablePisos').hide()
        }
    });
}

function addFlats() {

    $('#addFormFlats').click(function () {
        var formData = $('#formPisoAdd').serialize();
        $.ajax({
            type: "post",
            url: "/flat-add",
            data: formData,
            beforeSend: function () {
                $('#preloadSend').show();
            },
            success: function (response) {
                console.log(response);
                getFlatsAll();
                $('#preloadSend').hide();
                alertB5('alerts_piso', 'success', response.message);
                closeForm('formPisoAdd');
            },
            error: function (xhr, status, error) {
                $('#preloadSend').hide();
                errorList(xhr);

            }
        });

    });
}

function errorList(xhr) {
    var errors = xhr.responseJSON.errors;
    if (errors) {
        var errorMessage = '<ul>';
        $.each(errors, function (key, value) {
            errorMessage += '<li>' + value + '</li>';
        });
        errorMessage += '</ul>';
        $('.alert-send').html(
            '<div class="alert alert-danger alert-dismissible fade show" role="alert"><button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>' +
            errorMessage + '</div>');
    } else {
        console.error('Error desconocido:', error);
    }
}


function editFlats() {
    $('#editFormFlats').click(function() {
        var formData = $('#formPisoAdd').serialize();
        var idFlat = $('#idFlat').val()
        $.ajax({
            type: "put",
            url: "/flat-edit/"+ idFlat,
            data: formData,
            beforeSend: function() {
                $('#preloadSend').show();
            },
            success: function(response) {
                console.log(response);
                getFlatsAll();
                $('#preloadSend').hide();
                alertB5('alerts_piso', 'success', response.message);
                resetEditForm('formPisoAdd')
            },
            error: function(xhr, status, error) {
                $('#preloadSend').hide();
                errorList(xhr);
            }
        });
    });
}


function editValLFlat(){
    $(document).on('click', '.btn-edit-piso', function() {
        var idFlat = $(this).data('id');
        var flatData = {};
        $('#flatTable tbody tr').each(function() {
            var rowId = $(this).find('.btn-edit-piso').data('id');
            if (rowId === idFlat) {
                flatData.piso = $(this).find('td:nth-child(1)').text().trim();
                flatData.status = $(this).find('td:nth-child(2) .badge').text().trim();
                return false;
            }
        });
        $('#idFlat').val(idFlat);
        $('#name-flat').val(flatData.piso);
        $('#status-flat').val(flatData.status);
        $('#editFormFlats').show();
        $('#cancelFormFlats').show();
        $('#formTitleAdd').html('Editar "' + flatData.piso + '"')
        $('#addFormFlats').hide();

    });
}


function cancelFormEdit(idForm){
    $('#' + idForm + ' .btnformCancel').click(function(e) {
        e.preventDefault();
        resetEditForm('formPisoAdd')
    });
}


function resetEditForm(formEdit){
    $('#'+formEdit+' .btnFormEdit').hide();
    $('#'+formEdit+' .btnformCancel').hide();
    $('#'+formEdit+' .formTitle').html('Pisos o zonas')
    $('#'+formEdit+' .btnFormAdd').show();
    closeForm(formEdit);
}


function msgAlertDeleteTypeRoom(btn) {
    var dataId = $(btn).data('id');
    console.log('ID del elemento:', dataId);
    $.ajax({
        type: "POST",
        url: "/type-room-delete",
        data: {
            dataId: dataId,
            _token: token
        },
        beforeSend: function() {

        },
        success: function(response) {
            console.log(response.message);
            getTypeRoomsAll();
            alertB5('alerts_type', 'success', response.message);
        },
        error: function(xhr, status, error) {
            console.error('Error al eliminar el registro:', error);
            alertB5('alerts_type', 'success', error);
        }
    });
}
