$(document).ready(function() {
    const isDarkMode = localStorage.getItem('darkMode') === 'true';
    function toggleDarkMode() {
        $('body').toggleClass('dark');
        const isDark = $('body').hasClass('dark');
        localStorage.setItem('darkMode', isDark);

        // Cambiar los íconos según el modo
        if (isDark) {
            $('#toggleDark').find('.fa-moon-stars').show();
            $('#toggleDark').find('.fa-sun').hide();
        } else {
            $('#toggleDark').find('.fa-moon-stars').hide();
            $('#toggleDark').find('.fa-sun').show();
        }
    }
    if (isDarkMode) {
        $('body').addClass('dark');
        $('#toggleDark').find('.fa-moon-stars').show();
        $('#toggleDark').find('.fa-sun').hide();
    } else {
        $('#toggleDark').find('.fa-moon-stars').hide();
        $('#toggleDark').find('.fa-sun').show();
    }
    $('#toggleDark').click(toggleDarkMode);

    $('#btn-menu').click( function(e){
        $('#menu-h').slideToggle();
    })

    $('#btn-aside').click( function(){
        $('.aside-1').toggleClass('aside-show');
    })
});


function  dateBirth(year,month,day){
    const currentYear = new Date().getFullYear();
        const yearSelect = document.getElementById(year);
        const monthSelect = document.getElementById(month);
        const daySelect = document.getElementById(day);
        for (let year = currentYear; year >= currentYear - 100; year--) {
            const option = document.createElement('option');
            option.value = year;
            option.textContent = year;
            yearSelect.appendChild(option);
        }
        for (let month = 1; month <= 12; month++) {
            const option = document.createElement('option');
            option.value = month;
            option.textContent = month;
            monthSelect.appendChild(option);
        }
        function generateDays() {
            const selectedMonth = parseInt(monthSelect.value);
            const selectedYear = parseInt(yearSelect.value);
            const daysInMonth = new Date(selectedYear, selectedMonth, 0).getDate();
            daySelect.innerHTML = '';
            for (let day = 1; day <= daysInMonth; day++) {
                const option = document.createElement('option');
                option.value = day;
                option.textContent = day;
                daySelect.appendChild(option);
            }
        }
        yearSelect.addEventListener('change', generateDays);
        monthSelect.addEventListener('change', generateDays);
        generateDays();
}


function closeForm(id){
    $('#'+id)[0].reset();
}


function closeFormModal(id){
    closeForm(id);
    $('.alert-confirm').hide();
}


function datatableCreate(){
    $('.table').DataTable({
        "language": {
            "url": "//cdn.datatables.net/plug-ins/1.11.5/i18n/Spanish.json",
            "search": "Buscar:",
            "lengthMenu": "Mostrar _MENU_",
            "info": "Mostrando  _END_ filas de _TOTAL_",
            "infoEmpty": "0 resultados",
            "infoFiltered": "(Filtrado de _MAX_ filas)",
            "searchPlaceholder": "Buscar...",
            "paginate": {
                "previous": "<i class='fa-light fa-chevron-left'></i>",
                "next": "<i class='fa-light fa-chevron-right'></i>"
            }
        }
    });
}

function destruirTabla() {
    $('.table').DataTable().destroy();
}



function swal1(type,title,text){
    Swal.fire({
        icon: type,
        title: title,
        text: text,
    });
}


function alertB5(id, type, text) {
    $('#' + id).html('<div class="alert alert-' + type +
        ' alert-dismissible fade show" role="alert"><button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>' +
        text + '</div>');
    setTimeout(function() {
        $('#' + id + ' .alert').alert('close');
    }, 3000);
}

